package com.project.AttendanceSystem.entity;

public enum Role {
    STUDENT ,
    TEACHER
}

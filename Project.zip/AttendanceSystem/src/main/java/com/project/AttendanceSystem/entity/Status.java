package com.project.AttendanceSystem.entity;

public enum Status {
    PRESENT ,
    ABSENT
}
